"""
Submission template (USES trained weights).

Use this template if your agent depends on a trained neural network.
Place your saved model file (weights.pth) inside the submission folder.

The policy loads the model and uses it to predict the best action
from the observation.

The evaluator will import this file and call `policy(obs, rng)`.
"""

import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

ACTIONS = ("L45", "L22", "FW", "R22", "R45")

_MODEL = None


def _load_once():
    global _MODEL
    if _MODEL is not None:
        return

    submission_dir = os.path.dirname(__file__)
    wpath = os.path.join(submission_dir, "weights.pt")

    class PPOAgent(nn.Module):
        def __init__(self, obs_dim, act_dim):
            super(PPOAgent, self).__init__()

            self.shared = nn.Sequential(
                nn.Linear(obs_dim, 128),
                nn.ReLU(),
                nn.Linear(128, 128),
                nn.ReLU()
            )

            self.actor = nn.Linear(128, act_dim)
            self.critic = nn.Linear(128, 1)

        def forward(self, x):
            x = self.shared(x)
            logits = self.actor(x)
            return logits

    model = PPOAgent(18, 5)
    checkpoint = torch.load(wpath, map_location="cpu")
    model.load_state_dict(checkpoint["model_state_dict"])
    model.eval()

    _MODEL = model


def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    _load_once()

    import torch

    x = torch.from_numpy(obs.astype(np.float32)).unsqueeze(0)

    with torch.no_grad():
        q = _MODEL(x).squeeze(0).numpy()

    return ACTIONS[int(np.argmax(q))]