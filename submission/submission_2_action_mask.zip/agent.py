import os
import numpy as np
import torch
import torch.nn as nn

ACTIONS = ("L45", "L22", "FW", "R22", "R45")
LSTM_H_DIM = 128
MAX_STEPS = 800

_MODEL = None
_HX = None
_CX = None

DECAY = 0.95          # soft reset factor

step_counter = 0


def _load_once():
    global _MODEL, _HX, _CX

    if _MODEL is not None:
        return

    submission_dir = os.path.dirname(__file__)
    wpath = os.path.join(submission_dir, "weights.pth")

    class KnowledgeNet(nn.Module):
        def __init__(self, inDim=18, outDim=5, f_hDim=[512, 256], lstm_hDim=128, activation=nn.ReLU):
            super(KnowledgeNet, self).__init__()
            self.activation = activation

            prevDim = inDim
            layers = []
            for nextDim in f_hDim:
                layers.append(nn.Linear(prevDim, nextDim))
                layers.append(self.activation())
                prevDim = nextDim
            self.features = nn.Sequential(*layers)
            self.lstmCell = nn.LSTMCell(prevDim, lstm_hDim)

            self.values = nn.Linear(lstm_hDim, 1)
            self.advantages = nn.Linear(lstm_hDim, outDim)

            self.action_mask = nn.Sequential(
                nn.Linear(lstm_hDim + 1, 64),
                nn.ReLU(),
                nn.Linear(64, outDim),
                nn.Sigmoid()
            )

        def forward(self, x, hx, cx, time_frac=None):
            x_f = self.features(x)
            hx, cx = self.lstmCell(x_f, (hx, cx))

            v = self.values(hx)
            adv = self.advantages(hx)
            q_t = v + (adv - adv.mean(dim=1, keepdim=True))

            if time_frac is None:
                time_frac = torch.zeros(hx.shape[0], 1, device=hx.device)

            mask_input = torch.cat([hx.detach(), time_frac], dim=1)
            mask = self.action_mask(mask_input)
            q_masked = q_t * mask

            return q_masked, hx, cx, mask

    model = KnowledgeNet(f_hDim=[512, 256], lstm_hDim=LSTM_H_DIM)
    model.load_state_dict(torch.load(wpath, map_location="cpu"))
    model.eval()
    _MODEL = model

    _HX = torch.zeros(1, LSTM_H_DIM)
    _CX = torch.zeros(1, LSTM_H_DIM)


def reset_hidden_state():
    """Call this at the start of each new episode."""
    global _HX, _CX
    _HX = torch.zeros(1, LSTM_H_DIM)
    _CX = torch.zeros(1, LSTM_H_DIM)


def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    global _HX, _CX, step_counter
    _load_once()

    x = torch.from_numpy(obs.astype(np.float32)).unsqueeze(0)
    time_frac = torch.tensor([[step_counter / MAX_STEPS]], dtype=torch.float32)

    with torch.no_grad():
        q, _HX, _CX, _ = _MODEL(x, _HX, _CX, time_frac)
        _HX = (_HX * DECAY).detach()
        _CX = (_CX * DECAY).detach()

    q_np = q.squeeze(0).numpy()

    # Step tracking
    step_counter += 1

    if step_counter >= MAX_STEPS:
        reset_hidden_state()
        step_counter = 0

    return ACTIONS[int(np.argmax(q_np))]