"""
Submission template (USES trained weights).

Use this template if your agent depends on a trained neural network.
Place your saved model file (weights.pth) inside the submission folder.

The policy loads the model and uses it to predict the best action
from the observation.

The evaluator will import this file and call `policy(obs, rng)`.
"""

import os
import numpy as np
import torch
import torch.nn as nn

ACTIONS = ("L45", "L22", "FW", "R22", "R45")
LSTM_H_DIM = 256

_MODEL = None
_HX = None
_CX = None

DECAY = 0.95          # soft reset factor
MAX_STEPS = 800       # fallback hard reset

step_counter = 0


def _load_once():
    global _MODEL, _HX, _CX
    if _MODEL is not None:
        return

    submission_dir = os.path.dirname(__file__)
    wpath = os.path.join(submission_dir, "weights.pth")

    class KnowledgeNet(nn.Module):
        def __init__(self, inDim=18, outDim=5, f_hDim=[512, 256], lstm_hDim=128, activation=nn.ReLU):
            super(KnowledgeNet, self).__init__()
            self.activation = activation

            prevDim = inDim
            layers = []
            for nextDim in f_hDim:
                layers.append(nn.Linear(prevDim, nextDim))
                layers.append(self.activation())
                prevDim = nextDim
            self.features = nn.Sequential(*layers)
            self.lstmCell = nn.LSTMCell(prevDim, lstm_hDim)
            self.values = nn.Linear(lstm_hDim, 1)
            self.advantages = nn.Linear(lstm_hDim, outDim)

        def forward(self, x, hx, cx):
            x_f = self.features(x)
            hx, cx = self.lstmCell(x_f, (hx, cx))
            v = self.values(hx)
            adv = self.advantages(hx)
            q_t = v + (adv - adv.mean(dim=1, keepdim=True))
            return q_t, hx, cx

    model = KnowledgeNet(f_hDim=[512, 512, 256], lstm_hDim=LSTM_H_DIM)
    model.load_state_dict(torch.load(wpath, map_location="cpu"))
    model.eval()
    _MODEL = model

    # Initialize hidden state once at load time
    _HX = torch.zeros(1, LSTM_H_DIM)
    _CX = torch.zeros(1, LSTM_H_DIM)


def reset_hidden_state():
    """Call this at the start of each new episode."""
    global _HX, _CX
    _HX = torch.zeros(1, LSTM_H_DIM)
    _CX = torch.zeros(1, LSTM_H_DIM)


def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    global _HX, _CX, step_counter
    _load_once()

    x = torch.from_numpy(obs.astype(np.float32)).unsqueeze(0)

    with torch.no_grad():
        q, _HX, _CX = _MODEL(x, _HX, _CX)

        _HX = (_HX * DECAY).detach()
        _CX = (_CX * DECAY).detach()

    q_np = q.squeeze(0).numpy()

    # Step tracking
    step_counter += 1

    if step_counter >= MAX_STEPS:
        reset_hidden_state()
        step_counter = 0

    return ACTIONS[int(np.argmax(q_np))]