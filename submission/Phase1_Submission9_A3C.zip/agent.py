import os
import numpy as np
import torch
import torch.nn as nn

ACTIONS = ("L45", "L22", "FW", "R22", "R45")

_MODEL = None


# ================= A3C MODEL =================
class A3CAgent(nn.Module):
    def __init__(self, obs_dim=18, act_dim=5):
        super().__init__()

        self.shared_network = nn.Sequential(
            nn.Linear(obs_dim, 64),
            nn.ReLU(),
            nn.Linear(64, 64),
            nn.ReLU()
        )

        self.actor_network = nn.Linear(64, act_dim)
        self.critic_network = nn.Linear(64, 1)

    def forward(self, x):
        x = self.shared_network(x)
        logits = self.actor_network(x)
        return logits


# ================= LOAD MODEL =================
def _load_once():
    global _MODEL
    if _MODEL is not None:
        return

    submission_dir = os.path.dirname(__file__)
    wpath = os.path.join(submission_dir, "weights.pth")

    model = A3CAgent()
    
    checkpoint = torch.load(wpath, map_location="cpu")

    # If saved as dict
    if "model_state_dict" in checkpoint:
        model.load_state_dict(checkpoint["model_state_dict"])
    else:
        model.load_state_dict(checkpoint)

    model.eval()
    _MODEL = model


# ================= POLICY =================
def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    _load_once()

    x = torch.from_numpy(obs.astype(np.float32)).unsqueeze(0)

    with torch.no_grad():
        logits = _MODEL(x)
        action = torch.argmax(logits, dim=1).item()

    return ACTIONS[action]