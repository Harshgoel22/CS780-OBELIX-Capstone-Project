"""
Submission template (USES trained weights).

Use this template if your agent depends on a trained neural network.
Place your saved model file (weights.pth) inside the submission folder.

The policy loads the model and uses it to predict the best action
from the observation.

The evaluator will import this file and call `policy(obs, rng)`.
"""

import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

ACTIONS = ("L45", "L22", "FW", "R22", "R45")

_MODEL = None


def _load_once():
    global _MODEL
    if _MODEL is not None:
        return

    submission_dir = os.path.dirname(__file__)
    wpath = os.path.join(submission_dir, "weights.pth")

    class PolicyNetwork(nn.Module):
        def __init__(self, hDim=[64,64]):
            super(PolicyNetwork, self).__init__()
            self.activation = F.relu
            layers = []
            prev_dim = 18   # ⚠️ must match training

            for h in hDim:
                layers.append(nn.Linear(prev_dim, h))
                prev_dim = h

            layers.append(nn.Linear(prev_dim, 5))
            self.layers = nn.ModuleList(layers)

        def forward(self, x):
            for layer in self.layers[:-1]:
                x = self.activation(layer(x))
            x = self.layers[-1](x)
            return torch.softmax(x, dim=-1)

    full_state_dict = torch.load(wpath, map_location="cpu")

    actor_state_dict = {
        k.replace("actor_network.", ""): v
        for k, v in full_state_dict.items()
        if k.startswith("actor_network.")
    }

    model = PolicyNetwork(hDim=[64, 64])
    model.load_state_dict(actor_state_dict)
    model.eval()

    _MODEL = model


def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    _load_once()

    import torch

    x = torch.from_numpy(obs.astype(np.float32)).unsqueeze(0)

    with torch.no_grad():
        q = _MODEL(x).squeeze(0).numpy()

    return ACTIONS[int(np.argmax(q))]