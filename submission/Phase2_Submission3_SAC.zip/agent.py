"""
Submission template (USES trained weights).

Use this template if your agent depends on a trained neural network.
Place your saved model file (weights.pth) inside the submission folder.

The policy loads the model and uses it to predict the best action
from the observation.

The evaluator will import this file and call `policy(obs, rng)`.
"""

import os
import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F

ACTIONS = ("L45", "L22", "FW", "R22", "R45")

_MODEL = None


def _load_once():
    global _MODEL
    if _MODEL is not None:
        return

    submission_dir = os.path.dirname(__file__)
    wpath = os.path.join(submission_dir, "weights.pth")

    class DiscretePolicyNetwork(nn.Module):
        def __init__(self, stateDim=18, actionDim=5, hiddenDims=[256,256]):
            super(DiscretePolicyNetwork, self).__init__()

            layers = []
            prev_dim = stateDim

            for dim in hiddenDims:
                layers.append(nn.Linear(prev_dim, dim))
                layers.append(nn.ReLU())
                prev_dim = dim

            self.network = nn.Sequential(*layers)
            self.logits = nn.Linear(prev_dim, actionDim)

        def forward(self, state, action=None, deterministic=False):
            features = self.network(state)
            logits = self.logits(features)

            dist = torch.distributions.Categorical(logits=logits)

            if action is None:
                if deterministic:
                    action = logits.argmax(dim=-1)
                else:
                    action = dist.sample()

            log_prob = dist.log_prob(action)
            entropy = dist.entropy()

            return action, log_prob, entropy

    model = DiscretePolicyNetwork(hiddenDims=[256,256])
    model.load_state_dict(torch.load(wpath, map_location="cpu"))
    model.eval()

    _MODEL = model


def policy(obs: np.ndarray, rng: np.random.Generator) -> str:
    _load_once()

    import torch

    x = torch.from_numpy(obs.astype(np.float32)).unsqueeze(0)

    with torch.no_grad():
        action_idx, _, _ = _MODEL(x)
        action = action_idx.item()

    return ACTIONS[int(action)]